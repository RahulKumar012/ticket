package com.project.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.project.model.Train;

@Repository
public interface TrainDAO extends CrudRepository<Train, Integer>
{
	//Enquiry Component All Train Details which matching the Source and Destination
	List<Train> findBySource(String source);
	
	List<Train> findByDestination(String Destination);
}
