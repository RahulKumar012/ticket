package com.project.dao;

import org.springframework.data.repository.CrudRepository;

import com.project.model.BookedTicket;



public interface BookedTicketDAO extends CrudRepository<BookedTicket, Integer>
{

}
