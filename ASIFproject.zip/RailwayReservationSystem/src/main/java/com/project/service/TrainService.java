package com.project.service;

import java.util.*;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.dao.TrainDAO;
import com.project.model.Train;

@Service
public class TrainService
{
	@Autowired
	private TrainDAO traindao;
	

	/*public Train add(Train T) 
	{
		return traindao.save(T);
		
	}
	
	public void delete(int trainNumber)
	{
		traindao.deleteById(trainNumber);
	}
	
	public Train update(Train t) 
	{
		return traindao.save(t);
	}*/
	
	public Train getById(int trainNumber) {
		Train train = null;
		Optional<Train> opt = traindao.findById(trainNumber);
		if(opt.isPresent()) {
			train = opt.get();
		}
		return train;
	}
	
	//Enquiry Component All Trains Details
	public List<Train> getAll()
	{
		List<Train> trains = new ArrayList<Train>();
		Iterable<Train> it = traindao.findAll();
		it.forEach(train -> {
			trains.add(train);
		});
		return trains;
	}
	
	
	
	
	
	
}
