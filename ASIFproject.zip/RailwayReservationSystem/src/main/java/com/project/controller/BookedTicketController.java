package com.project.controller;
import com.project.model.BookedTicket;

import com.project.model.Train;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.project.model.BookedTicket;
import com.project.service.BookedTicketService;

@RestController
public class BookedTicketController 
{
	@Autowired
	private BookedTicketService  bookService;
	
	
	@GetMapping("/ticket")
	List<BookedTicket> list(){
		return bookService.getAll();
		
	}
}
